import { db } from "@/lib/db";

const tasks = [
  // Week 1
  { day: 1, title: "Foundation + Syzygy Establishment", status: "completed", milestone: "M1", week: 1, reportRef: "NR-000 through NR-010" },
  { day: 2, title: "Firewall hardening (UFW), Ollama v0.31.1 + ROCm 7.2 GPU inference", status: "completed", milestone: "M1", week: 1, reportRef: "NR-013/NR-016" },
  { day: 3, title: "VSCodium + Continue.dev config, wire to Ollama", status: "pending", milestone: "M1", week: 1 },
  { day: 4, title: "Pull models (Qwen3:8b, TinyLlama, Nomic-embed-text), verify inference API", status: "completed", milestone: "M1", week: 1 },
  { day: 5, title: "Debug GPU & Inference issues resolved (ROCm 7.2 ABI mismatch, tmpfs overflow)", status: "completed", milestone: "M1", week: 1, reportRef: "NR-013" },
  { day: 6, title: "Milestone check: Core infrastructure operational (Ollama+UFW done)", status: "completed", milestone: "M2", week: 1 },
  { day: 7, title: "Milestone check: Core infrastructure operational", status: "completed", milestone: "M2", week: 1 },

  // Week 2
  { day: 8, title: "Wire agent tools to local Ollama API (/api/embed, /api/chat)", status: "completed", milestone: "M3", week: 2 },
  { day: 9, title: "Build custom agent tools: vault_operations.py + index_memory.py", status: "completed", milestone: "M3", week: 2, reportRef: "NR-017" },
  { day: 10, title: "Interactive Mode Verification: Semantic search /search retrieves context", status: "completed", milestone: "M3", week: 2, reportRef: "NR-017" },
  { day: 11, title: "Create systemd services for nova-tools scripts", status: "pending", milestone: "M3", week: 2 },
  { day: 12, title: "Obsidian vault operational (Living File anchor)", status: "completed", milestone: "M4", week: 2 },
  { day: 13, title: "Seed Vault Architecture (00_System through 05_Templates)", status: "completed", milestone: "M4", week: 2 },
  { day: 14, title: "Milestone check: Custom agent pipeline responds to prompts, Vault active", status: "pending", milestone: "M4", week: 2 },

  // Week 3
  { day: 15, title: "Install LanceDB in isolated uv venv, build index_memory.py", status: "completed", milestone: "M5", week: 3, reportRef: "NR-017" },
  { day: 16, title: "Build vault_operations.py (read/write/append)", status: "completed", milestone: "M5", week: 3, reportRef: "NR-017" },
  { day: 17, title: "Verify Git Auto-Commits on vault writes via Python script", status: "pending", milestone: "M5", week: 3 },
  { day: 18, title: "Verify /search command retrieves context via vector similarity", status: "completed", milestone: "M5", week: 3, reportRef: "NR-017" },
  { day: 19, title: "Initialize Next.js NovaHub Dashboard", status: "completed", milestone: "M6", week: 3 },
  { day: 20, title: "Build API Routes & UI Components", status: "completed", milestone: "M6", week: 3 },
  { day: 21, title: "Milestone check: Memory pipeline and Dashboard live", status: "pending", milestone: "M6", week: 3 },

  // Week 4
  { day: 22, title: "Register vault_operations as MCP tool / CLI alias", status: "pending", milestone: "M7", week: 4 },
  { day: 23, title: "Test Agent Write-Access: Syzygy, save this to...", status: "pending", milestone: "M7", week: 4 },
  { day: 24, title: "Install Open Notebook (Native build, NO Docker)", status: "pending", milestone: "M7", week: 4 },
  { day: 25, title: "Sovereignty Hack: Wire Open Notebook to local Ollama", status: "pending", milestone: "M7", week: 4 },
  { day: 26, title: "Wire Open Notebook TTS to local Kokoro instance", status: "pending", milestone: "M8", week: 4 },
  { day: 27, title: "End-to-end RAG: PDF → Query → Summary → Vault", status: "pending", milestone: "M8", week: 4 },
  { day: 28, title: "Test Audio Briefing pipeline: PDF → Kokoro → MP3", status: "pending", milestone: "M8", week: 4 },
  { day: 29, title: "Auto-index verification: logs hit LanceDB & Episodic", status: "pending", milestone: "M8", week: 4 },
  { day: 30, title: "Sovereignty Audit: Zero cloud API calls. System stabilized.", status: "pending", milestone: "M8", week: 4 },
];

const services = [
  { name: "Ollama", status: "running", port: 11434, protocol: "HTTP", detail: "v0.31.1 — ROCm 7.2 GPU inference (qwen3:8b, tinyllama, nomic-embed-text)", category: "core" },
  { name: "NovaHub Dashboard", status: "running", port: 3000, protocol: "HTTP", detail: "Prisma/SQLite at 99_Meta/nova.db", category: "core" },
  { name: "LanceDB", status: "running", port: null, protocol: "Embedded", detail: "~/.hermes/lancedb — nomic-embed-text embeddings via Ollama", category: "core" },
  { name: "UFW Firewall", status: "running", port: null, protocol: "System", detail: "Active — ports 11434 + 3000 open", category: "core" },
  { name: "Obsidian", status: "running", port: null, protocol: "AppImage", detail: "v1.12.7 — Syzygy theme active, vault at ~/nova-vault/", category: "tool" },
  { name: "ROCm", status: "running", port: null, protocol: "Kernel", detail: "v7.1 — RX 9060 XT, 32 CUs, 16GB VRAM, 38°C", category: "core" },
  { name: "nova-tools", status: "running", port: null, protocol: "Python", detail: "uv venv — vault_operations.py + index_memory.py", category: "agent" },
  { name: "Open Notebook", status: "not_installed", port: 8888, protocol: "HTTP", detail: "Planned — Day 24", category: "planned" },
  { name: "Kokoro TTS", status: "not_installed", port: null, protocol: "HTTP", detail: "Planned — Day 26", category: "planned" },
  { name: "Syzygy Guardian", status: "running", port: null, protocol: "Agent", detail: "Alignment engine — mood/tunnel routing, vault-aware", category: "agent" },
  { name: "Ponytail", status: "running", port: null, protocol: "Plugin", detail: "OpenCode YAGNI ruleset — lazy senior dev skill", category: "tool" },
  { name: "Node.js", status: "running", port: null, protocol: "Runtime", detail: "v22.22.1", category: "core" },
  { name: "pnpm", status: "running", port: null, protocol: "CLI", detail: "v11.9.0", category: "tool" },
  { name: "uv", status: "running", port: null, protocol: "CLI", detail: "v0.11.26", category: "tool" },
];

async function main() {
  // Clear existing data
  await db.sprintTask.deleteMany();
  await db.systemService.deleteMany();

  // Seed tasks
  for (const t of tasks) {
    await db.sprintTask.create({ data: t });
  }

  // Seed services
  for (const s of services) {
    await db.systemService.create({ data: s });
  }

  const taskCount = await db.sprintTask.count();
  const serviceCount = await db.systemService.count();
  console.log(`Seeded ${taskCount} sprint tasks and ${serviceCount} system services.`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());