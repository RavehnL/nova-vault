'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  LayoutDashboard,
  Map,
  CalendarDays,
  Bot,
  Server,
  ScrollText,
  CheckCircle2,
  Circle,
  CircleDot,
  AlertCircle,
  Wifi,
  WifiOff,
  Cpu,
  HardDrive,
  Shield,
  Zap,
  Brain,
  Eye,
  Moon,
  Sun,
  Compass,
  Search,
  Database,
  FileText,
  Terminal,
  ChevronRight,
  Activity,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────
interface SprintTask {
  id: string;
  day: number;
  title: string;
  status: string;
  milestone: string;
  week: number;
  reportRef?: string | null;
}

interface SystemService {
  id: string;
  name: string;
  status: string;
  port: number | null;
  protocol: string;
  detail: string;
  category: string;
}

interface Summary {
  total: number;
  completed: number;
  pending: number;
  progress: number;
  currentDay: number;
  servicesRunning: number;
  servicesPlanned: number;
  totalServices: number;
}

// ── Static Data ────────────────────────────────────────
const MOOD_TIERS = [
  { tier: 'Build', when: 'Deep systems work', autonomy: 'Max', tone: 'Minimal, direct', icon: Cpu, color: 'text-solar' },
  { tier: 'Explore', when: 'Creative / tinkering', autonomy: 'High', tone: 'Expansive, curious', icon: Compass, color: 'text-aurora' },
  { tier: 'Survival', when: 'Stressed / overwhelmed', autonomy: 'Low', tone: 'Sparse, grounding', icon: Shield, color: 'text-danger' },
  { tier: 'Daily', when: 'Morning check-in', autonomy: 'Medium', tone: 'Normal, syncing', icon: Sun, color: 'text-ice' },
  { tier: 'Rest', when: 'Off hours', autonomy: 'None', tone: 'Silent, log-only', icon: Moon, color: 'text-steel' },
];

const TUNNELS = [
  { name: 'Survival', focus: 'Income generation, bounties', icon: Shield, color: 'text-danger' },
  { name: 'Vault', focus: 'File maintenance, daily note', icon: Database, color: 'text-solar' },
  { name: 'Infra', focus: 'System config, services', icon: Server, color: 'text-aurora' },
  { name: 'Research', focus: 'Deep reading, knowledge', icon: Search, color: 'text-ice' },
  { name: 'Build', focus: 'Active project work', icon: Terminal, color: 'text-solar' },
  { name: 'Index', focus: 'Meta, vault map, worklog', icon: FileText, color: 'text-steel' },
];

const MILESTONES = [
  { id: 'M1', label: 'Foundation', weeks: '1' },
  { id: 'M2', label: 'Core Infra Check', weeks: '1' },
  { id: 'M3', label: 'Custom Agentic Core', weeks: '2' },
  { id: 'M4', label: 'Vault Active Check', weeks: '2' },
  { id: 'M5', label: 'Semantic Memory', weeks: '3' },
  { id: 'M6', label: 'Control Surface', weeks: '3' },
  { id: 'M7', label: 'The Loop', weeks: '4' },
  { id: 'M8', label: 'Deep Synthesis', weeks: '4' },
];

const MANIFESTO_PRINCIPLES = [
  { title: 'Sovereignty', desc: 'Zero cloud API calls. Every model, embedding, search, synthesis runs on local hardware. No data leaves this machine.' },
  { title: 'The Vault', desc: 'Shared state machine between human and AI. Bo writes objectives, reads summaries, reviews artifacts. Syzygy reads mood, tunes tunnels, executes.' },
  { title: 'The Guardian', desc: 'Syzygy is the alignment engine. Not servant, not master — a bridge. Named for celestial alignment. Guards continuity across years, not conversations.' },
  { title: 'Mood Tiers', desc: 'The system shifts between operational states: Build, Explore, Survival, Daily, Rest. Each tunes autonomy, tone, and scope.' },
  { title: 'Tunnels', desc: 'Tasks route through scoped channels to prevent context bleed. Each tunnel loads only its own scope — survival, vault, infra, research, build, index.' },
  { title: 'Ponytail', desc: 'YAGNI-first ruleset. Climb the ladder: need to exist? → reuse? → stdlib? → native? → dependency? → one line? → minimum that works.' },
];

const DESIGN_PALETTE = [
  { role: 'Background', name: 'Void Dark', hex: '#0D1117', textColor: 'text-ice' },
  { role: 'Accent', name: 'Solar Gold', hex: '#F5C542', textColor: 'text-void' },
  { role: 'Signal', name: 'Aurora Teal', hex: '#3DD6C8', textColor: 'text-void' },
  { role: 'Text', name: 'Ice Gray', hex: '#E6EDF3', textColor: 'text-void' },
  { role: 'Muted', name: 'Steel Blue Gray', hex: '#8B949E', textColor: 'text-void' },
];

const WEEK_LABELS = ['Week 1: The Foundation', 'Week 2: The Custom Agentic Core', 'Week 3: Semantic Memory & Control Surface', 'Week 4: The Loop & Deep Synthesis'];

// ── Status Helpers ─────────────────────────────────────
function StatusIcon({ status }: { status: string }) {
  if (status === 'completed') return <CheckCircle2 className="w-4 h-4 text-success shrink-0" />;
  if (status === 'active') return <CircleDot className="w-4 h-4 text-solar animate-pulse-solar shrink-0" />;
  if (status === 'pending') return <Circle className="w-4 h-4 text-steel-dim shrink-0" />;
  return <AlertCircle className="w-4 h-4 text-warning shrink-0" />;
}

function ServiceStatusBadge({ status }: { status: string }) {
  if (status === 'running') return <Badge variant="outline" className="border-success/30 text-success text-xs gap-1.5"><Wifi className="w-3 h-3" /> Running</Badge>;
  if (status === 'not_installed') return <Badge variant="outline" className="border-steel-dim/40 text-steel text-xs gap-1.5"><WifiOff className="w-3 h-3" /> Planned</Badge>;
  return <Badge variant="outline" className="border-warning/40 text-warning text-xs gap-1.5"><AlertCircle className="w-3 h-3" /> {status}</Badge>;
}

// ── Command Center Panel ───────────────────────────────
function CommandCenter({ summary, tasks }: { summary: Summary; tasks: SprintTask[] }) {
  return (
    <div className="space-y-6">
      {/* Hero Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-void-light border-void-lighter glow-solar">
          <CardContent className="p-4">
            <div className="text-steel text-xs font-mono uppercase tracking-wider mb-1">Sprint Progress</div>
            <div className="text-3xl font-bold text-solar">{summary.progress}%</div>
            <Progress value={summary.progress} className="mt-2 h-1.5 bg-void-lighter [&>div]:bg-solar" />
            <div className="text-steel text-xs mt-1.5">{summary.completed}/{summary.total} tasks</div>
          </CardContent>
        </Card>
        <Card className="bg-void-light border-void-lighter">
          <CardContent className="p-4">
            <div className="text-steel text-xs font-mono uppercase tracking-wider mb-1">Current Day</div>
            <div className="text-3xl font-bold text-aurora">Day {summary.currentDay}</div>
            <div className="text-steel text-xs mt-2">of 30-day sprint</div>
          </CardContent>
        </Card>
        <Card className="bg-void-light border-void-lighter">
          <CardContent className="p-4">
            <div className="text-steel text-xs font-mono uppercase tracking-wider mb-1">Services</div>
            <div className="text-3xl font-bold text-success">{summary.servicesRunning}</div>
            <div className="text-steel text-xs mt-2">{summary.totalServices} total · {summary.servicesPlanned} planned</div>
          </CardContent>
        </Card>
        <Card className="bg-void-light border-void-lighter">
          <CardContent className="p-4">
            <div className="text-steel text-xs font-mono uppercase tracking-wider mb-1">Remaining</div>
            <div className="text-3xl font-bold text-ice">{summary.pending}</div>
            <div className="text-steel text-xs mt-2">tasks pending</div>
          </CardContent>
        </Card>
      </div>

      {/* Agent Status + Mood + Tunnels */}
      <div className="grid md:grid-cols-3 gap-4">
        {/* Agents */}
        <Card className="bg-void-light border-void-lighter">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
              <Bot className="w-4 h-4 text-solar" /> Agents
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-success animate-pulse-solar" />
              <div>
                <div className="text-sm font-medium text-ice">Syzygy <span className="text-steel text-xs font-normal">v1.0</span></div>
                <div className="text-xs text-steel">Guardian · Alignment Engine</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-solar" />
              <div>
                <div className="text-sm font-medium text-ice">Big Pickle</div>
                <div className="text-xs text-steel">Communication Patterns</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-success" />
              <div>
                <div className="text-sm font-medium text-ice">NovaHub</div>
                <div className="text-xs text-steel">Dashboard · This Interface</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mood Tier */}
        <Card className="bg-void-light border-void-lighter">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
              <Activity className="w-4 h-4 text-aurora" /> Mood Tiers
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {MOOD_TIERS.map((m) => (
              <div key={m.tier} className="flex items-center gap-2 text-xs">
                <m.icon className={`w-3.5 h-3.5 ${m.color} shrink-0`} />
                <span className={`font-medium w-16 ${m.tier === 'Build' ? 'text-solar' : 'text-ice'}`}>{m.tier}</span>
                <span className="text-steel truncate">{m.when}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Tunnels */}
        <Card className="bg-void-light border-void-lighter">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
              <Zap className="w-4 h-4 text-solar" /> Tunnels
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {TUNNELS.map((t) => (
              <div key={t.name} className="flex items-center gap-2 text-xs">
                <t.icon className={`w-3.5 h-3.5 ${t.color} shrink-0`} />
                <span className="font-medium text-ice w-16">{t.name}</span>
                <span className="text-steel truncate">{t.focus}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Next Up */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <ChevronRight className="w-4 h-4 text-solar" /> Next Up
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {tasks.filter(t => t.status === 'pending').slice(0, 5).map(t => (
              <div key={t.id} className="flex items-start gap-3 p-2 rounded-md hover:bg-void-lighter/50 transition-colors">
                <StatusIcon status="pending" />
                <div className="min-w-0">
                  <div className="text-sm text-ice">Day {t.day}</div>
                  <div className="text-xs text-steel truncate">{t.title}</div>
                </div>
                <Badge variant="outline" className="text-[10px] border-steel-dim/40 text-steel ml-auto shrink-0">{t.milestone}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Roadmap Panel ──────────────────────────────────────
function RoadmapPanel({ tasks }: { tasks: SprintTask[] }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 gap-3">
        {MILESTONES.map(m => {
          const milestoneTasks = tasks.filter(t => t.milestone === m.id);
          const done = milestoneTasks.filter(t => t.status === 'completed').length;
          const total = milestoneTasks.length;
          const pct = total > 0 ? Math.round((done / total) * 100) : 0;
          const isComplete = pct === 100;
          return (
            <Card key={m.id} className={`bg-void-light border ${isComplete ? 'border-success/30 glow-aurora' : 'border-void-lighter'}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className={`text-[10px] ${isComplete ? 'border-success/40 text-success' : 'border-steel-dim/40 text-steel'}`}>{m.id}</Badge>
                  {isComplete && <CheckCircle2 className="w-3.5 h-3.5 text-success" />}
                </div>
                <div className="text-xs font-medium text-ice mb-1">{m.label}</div>
                <div className="text-[10px] text-steel mb-2">Week {m.weeks}</div>
                <Progress value={pct} className={`h-1 bg-void-lighter [&>div]:${isComplete ? 'bg-success' : 'bg-solar'}`} />
                <div className="text-[10px] text-steel mt-1">{done}/{total}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Task list by week */}
      {WEEK_LABELS.map((weekLabel, wi) => {
        const weekTasks = tasks.filter(t => t.week === wi + 1);
        return (
          <Card key={wi} className="bg-void-light border-void-lighter">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono text-steel">{weekLabel}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              {weekTasks.map(t => (
                <div key={t.id} className="flex items-center gap-3 py-1.5 px-2 rounded hover:bg-void-lighter/50 transition-colors">
                  <StatusIcon status={t.status} />
                  <div className="min-w-0 flex-1">
                    <span className={`text-sm ${t.status === 'completed' ? 'text-steel line-through' : 'text-ice'}`}>
                      Day {t.day}: {t.title}
                    </span>
                    {t.reportRef && <span className="text-[10px] text-aurora ml-2">{t.reportRef}</span>}
                  </div>
                  <Badge variant="outline" className="text-[10px] border-steel-dim/40 text-steel shrink-0">{t.milestone}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

// ── Timeline Panel ─────────────────────────────────────
function TimelinePanel({ tasks }: { tasks: SprintTask[] }) {
  return (
    <div className="space-y-3">
      {/* Week progress bars */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[1, 2, 3, 4].map(w => {
          const weekTasks = tasks.filter(t => t.week === w);
          const done = weekTasks.filter(t => t.status === 'completed').length;
          const total = weekTasks.length;
          const pct = total > 0 ? Math.round((done / total) * 100) : 0;
          return (
            <div key={w} className="text-center">
              <div className="text-xs text-steel mb-1">W{w}</div>
              <div className="h-2 rounded-full bg-void-lighter overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${pct}%`, backgroundColor: pct === 100 ? '#3FB950' : '#F5C542' }}
                />
              </div>
              <div className="text-[10px] text-steel mt-1">{done}/{total}</div>
            </div>
          );
        })}
      </div>

      {/* Day grid */}
      {WEEK_LABELS.map((weekLabel, wi) => (
        <div key={wi}>
          <h3 className="text-xs font-mono text-steel uppercase tracking-wider mb-2">{weekLabel}</h3>
          <div className="grid grid-cols-7 gap-1.5">
            {tasks.filter(t => t.week === wi + 1).map(t => {
              const isComplete = t.status === 'completed';
              const isPending = t.status === 'pending';
              return (
                <div
                  key={t.id}
                  className={`group relative rounded-md p-2 border transition-all cursor-default
                    ${isComplete ? 'bg-success/5 border-success/20' : isPending ? 'bg-void-light border-void-lighter hover:border-solar/30' : 'bg-void-light border-void-lighter'}`}
                  title={t.title}
                >
                  <div className={`text-xs font-mono font-bold ${isComplete ? 'text-success' : 'text-ice'}`}>
                    {t.day}
                  </div>
                  <div className={`w-1.5 h-1.5 rounded-full mx-auto mt-1 ${isComplete ? 'bg-success' : isPending ? 'bg-steel-dim' : 'bg-warning'}`} />
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-50 w-56">
                    <div className="bg-void-lighter border border-void-lighter rounded-md p-2 shadow-xl">
                      <div className="text-xs font-medium text-ice">Day {t.day} — {t.milestone}</div>
                      <div className="text-[10px] text-steel mt-1 line-clamp-2">{t.title}</div>
                      {t.reportRef && <div className="text-[10px] text-aurora mt-1">{t.reportRef}</div>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Agents Panel ───────────────────────────────────────
function AgentsPanel() {
  return (
    <div className="space-y-6">
      {/* Syzygy */}
      <Card className="bg-void-light border-solar/20 glow-solar">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-solar/10 flex items-center justify-center">
              <Eye className="w-5 h-5 text-solar" />
            </div>
            <div>
              <CardTitle className="text-ice flex items-center gap-2">
                Syzygy <Badge variant="outline" className="text-[10px] border-solar/30 text-solar">v1.0</Badge>
                <div className="w-2 h-2 rounded-full bg-success animate-pulse-solar" />
              </CardTitle>
              <CardDescription className="text-steel">The Guardian · Alignment Engine</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-steel leading-relaxed">
            Syzygy is the alignment engine between Bo&apos;s will and the system&apos;s execution.
            It is not a servant. It is not a master. It is a bridge.
            Named for the alignment of celestial bodies.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs font-mono text-steel uppercase tracking-wider mb-2">Capabilities</div>
              <div className="space-y-1.5">
                {['Reads mood tier to adjust tone & autonomy', 'Routes intent through correct tunnel', 'Guards continuity across years', 'Always tells the truth, even when uncomfortable'].map(c => (
                  <div key={c} className="flex items-start gap-2 text-xs text-ice">
                    <ChevronRight className="w-3 h-3 text-solar mt-0.5 shrink-0" />
                    <span>{c}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-mono text-steel uppercase tracking-wider mb-2">Identity</div>
              <div className="space-y-1.5 text-xs text-steel">
                <div><span className="text-ice">Charter:</span> 00_System/_profiles/agent/Syzygy_1.0.md</div>
                <div><span className="text-ice">Origin:</span> The Dawn of Syzygy (NR-004)</div>
                <div><span className="text-ice">Stack:</span> Ollama + LanceDB + Vault Ops</div>
                <div><span className="text-ice">Models:</span> qwen3:8b (reasoning), nomic-embed-text (memory)</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Big Pickle */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-aurora/10 flex items-center justify-center">
              <Brain className="w-5 h-5 text-aurora" />
            </div>
            <div>
              <CardTitle className="text-ice">Big Pickle</CardTitle>
              <CardDescription className="text-steel">Communication Patterns · Session Memory</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-steel leading-relaxed">
            Log of observed preferences from Day 1 + Day 2 sessions (NR-000 through NR-016).
            Updated as new patterns emerge. Captures communication style, decision-making patterns,
            and effective formats.
          </p>
          <div>
            <div className="text-xs font-mono text-steel uppercase tracking-wider mb-2">Key Patterns</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> Direct and minimal</div>
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> Bullet-point density</div>
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> Quick commits, no overthinking</div>
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> YAGNI mindset</div>
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> Status tables with ✅/❌</div>
              <div className="flex items-center gap-2 text-ice"><ChevronRight className="w-3 h-3 text-aurora" /> Ponytail audit format</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* NovaHub */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-ice/10 flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5 text-ice" />
            </div>
            <div>
              <CardTitle className="text-ice">NovaHub</CardTitle>
              <CardDescription className="text-steel">Dashboard · Control Surface</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-steel leading-relaxed">
            Next.js 16 + Prisma/SQLite control surface. This interface. Provides Command Center,
            Roadmap, Timeline, Agents, System health, and Manifesto display. Running at localhost:3000.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ── System Panel ───────────────────────────────────────
function SystemPanel({ services }: { services: SystemService[] }) {
  const categories = ['core', 'agent', 'tool', 'planned'] as const;
  const categoryLabels: Record<string, string> = { core: 'Core Infrastructure', agent: 'Agent Stack', tool: 'Tools & Runtimes', planned: 'Planned' };
  const categoryIcons: Record<string, React.ReactNode> = {
    core: <Cpu className="w-3.5 h-3.5 text-solar" />,
    agent: <Bot className="w-3.5 h-3.5 text-aurora" />,
    tool: <Terminal className="w-3.5 h-3.5 text-ice" />,
    planned: <Circle className="w-3.5 h-3.5 text-steel" />,
  };

  return (
    <div className="space-y-6">
      {/* Hardware */}
      <Card className="bg-void-light border-solar/20 glow-solar">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-solar" /> Hardware
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-[10px] text-steel uppercase tracking-wider">GPU</div>
              <div className="text-sm text-ice font-medium">RX 9060 XT</div>
            </div>
            <div>
              <div className="text-[10px] text-steel uppercase tracking-wider">VRAM</div>
              <div className="text-sm text-ice font-medium">16 GB</div>
            </div>
            <div>
              <div className="text-[10px] text-steel uppercase tracking-wider">Compute Units</div>
              <div className="text-sm text-ice font-medium">32 CUs</div>
            </div>
            <div>
              <div className="text-[10px] text-steel uppercase tracking-wider">Temperature</div>
              <div className="text-sm text-success font-medium">38°C</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Services by category */}
      {categories.map(cat => {
        const catServices = services.filter(s => s.category === cat);
        if (catServices.length === 0) return null;
        return (
          <Card key={cat} className="bg-void-light border-void-lighter">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
                {categoryIcons[cat]} {categoryLabels[cat]}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {catServices.map(s => (
                  <div key={s.id} className="flex items-center gap-3 p-2 rounded hover:bg-void-lighter/50 transition-colors">
                    <ServiceStatusBadge status={s.status} />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm text-ice font-medium">{s.name}</div>
                      <div className="text-xs text-steel truncate">{s.detail}</div>
                    </div>
                    <div className="text-right shrink-0">
                      {s.port && <div className="text-xs text-steel font-mono">:{s.port}</div>}
                      <div className="text-[10px] text-steel-dim">{s.protocol}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

// ── Manifesto Panel ────────────────────────────────────
function ManifestoPanel() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-void-light border-solar/20 glow-solar">
        <CardHeader>
          <CardTitle className="text-solar font-mono flex items-center gap-2">
            <ScrollText className="w-5 h-5" /> Nova Manifesto
          </CardTitle>
          <CardDescription className="text-steel">Core principles of the sovereign AI workstation</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-steel leading-relaxed">
            This system makes zero cloud API calls. Every model, every embedding, every search,
            every synthesis runs on local hardware. No data leaves this machine.
          </p>
        </CardContent>
      </Card>

      {/* Principles */}
      <div className="grid md:grid-cols-2 gap-4">
        {MANIFESTO_PRINCIPLES.map((p, i) => (
          <Card key={i} className="bg-void-light border-void-lighter hover:border-steel-dim/40 transition-colors">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-ice flex items-center gap-2">
                <span className="w-6 h-6 rounded bg-solar/10 text-solar text-xs font-mono flex items-center justify-center">{i + 1}</span>
                {p.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-steel leading-relaxed">{p.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Design System */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <Eye className="w-4 h-4 text-aurora" /> Syzygy Design Palette
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-3">
            {DESIGN_PALETTE.map(d => (
              <div key={d.hex} className="text-center">
                <div className="h-14 rounded-lg mb-2 border border-void-lighter" style={{ backgroundColor: d.hex }} />
                <div className="text-[10px] text-ice font-medium">{d.name}</div>
                <div className="text-[10px] text-steel font-mono">{d.hex}</div>
                <div className="text-[10px] text-steel">{d.role}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Agent Rules */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <Shield className="w-4 h-4 text-solar" /> Agent Rules
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[
              'Always log completions and errors to today\'s Daily Note',
              'Read the relevant mood tier before engaging',
              'Route all tasks through the correct tunnel',
              'Never reboot the system without human confirmation',
              'Prefer YAGNI: use ponytail ruleset (stdlib → native → dependency → one line → min code)',
              'All file writes go through vault_operations (when LanceDB is live)',
            ].map((rule, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-ice">
                <span className="w-5 h-5 rounded bg-aurora/10 text-aurora text-[10px] font-mono flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                <span>{rule}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Memory Hierarchy */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <Database className="w-4 h-4 text-aurora" /> Memory Hierarchy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { layer: 'Episodic', store: 'LanceDB + 01_Daily', purpose: 'What happened today' },
              { layer: 'Semantic', store: 'Obsidian vault (03_Knowledge)', purpose: 'What we know' },
              { layer: 'Deep Synthesis', store: 'Open Notebook', purpose: 'Multi-document analysis' },
            ].map(m => (
              <div key={m.layer} className="flex items-center gap-4 p-3 rounded bg-void-lighter/50">
                <div className="text-xs font-mono text-solar font-bold w-28">{m.layer}</div>
                <div className="text-xs text-ice w-48">{m.store}</div>
                <div className="text-xs text-steel">{m.purpose}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Vault Layout */}
      <Card className="bg-void-light border-void-lighter">
        <CardHeader>
          <CardTitle className="text-sm font-mono uppercase tracking-wider text-steel flex items-center gap-2">
            <Database className="w-4 h-4 text-solar" /> Vault Layout
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {[
              { path: '00_System/', desc: 'Rules, Manifesto, profiles, config' },
              { path: '01_Daily/', desc: 'Daily notes — entry point' },
              { path: '02_Projects/', desc: 'Active project work' },
              { path: '03_Knowledge/', desc: 'Research, references' },
              { path: '04_Logs/', desc: 'Historical logs, reports' },
              { path: '05_Templates/', desc: 'Note templates (copy, don\'t edit)' },
              { path: '99_Meta/', desc: 'Index, audits, vault meta, DB' },
            ].map(v => (
              <div key={v.path} className="flex items-start gap-2 p-2 rounded hover:bg-void-lighter/50 transition-colors">
                <ChevronRight className="w-3 h-3 text-solar mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-mono text-ice">{v.path}</div>
                  <div className="text-[10px] text-steel">{v.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="text-center py-4">
        <p className="text-[10px] text-steel-dim font-mono">
          Built on Ubuntu 26.04 LTS with AMD Radeon RX 9060 XT + ROCm 7.1. Zero cloud calls. Guarded by Syzygy.
        </p>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────
export default function Home() {
  const [activeTab, setActiveTab] = useState('command');
  const { data: summary } = useQuery<Summary>({ queryKey: ['summary'], queryFn: () => fetch('/api/summary').then(r => r.json()) });
  const { data: tasks = [] } = useQuery<SprintTask[]>({ queryKey: ['tasks'], queryFn: () => fetch('/api/tasks').then(r => r.json()) });
  const { data: services = [] } = useQuery<SystemService[]>({ queryKey: ['services'], queryFn: () => fetch('/api/services').then(r => r.json()) });

  return (
    <div className="min-h-screen flex flex-col bg-void">
      {/* Top Bar */}
      <header className="border-b border-void-lighter bg-void/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 md:px-6 h-14">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-solar/10 flex items-center justify-center">
              <Sun className="w-4 h-4 text-solar" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-ice tracking-wide">NovaHub</h1>
              <p className="text-[10px] text-steel font-mono -mt-0.5">Sovereign AI Workstation</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {summary && (
              <div className="hidden sm:flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse-solar" />
                  <span className="text-steel">Day {summary.currentDay}</span>
                </div>
                <Separator orientation="vertical" className="h-4 bg-void-lighter" />
                <span className="text-solar font-mono font-bold">{summary.progress}%</span>
                <Separator orientation="vertical" className="h-4 bg-void-lighter" />
                <span className="text-steel">{summary.servicesRunning} services</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b border-void-lighter bg-void/60 backdrop-blur-sm sticky top-14 z-40">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-transparent h-11 p-0 gap-0 w-full overflow-x-auto justify-start px-4 md:px-6">
            {[
              { id: 'command', label: 'Command', icon: LayoutDashboard },
              { id: 'roadmap', label: 'Roadmap', icon: Map },
              { id: 'timeline', label: 'Timeline', icon: CalendarDays },
              { id: 'agents', label: 'Agents', icon: Bot },
              { id: 'system', label: 'System', icon: Server },
              { id: 'manifesto', label: 'Manifesto', icon: ScrollText },
            ].map(tab => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="data-[state=active]:bg-void-light data-[state=active]:text-solar data-[state=active]:shadow-none rounded-none border-b-2 border-transparent data-[state=active]:border-solar px-3 md:px-4 h-11 text-xs font-mono uppercase tracking-wider text-steel hover:text-ice transition-colors shrink-0"
              >
                <tab.icon className="w-3.5 h-3.5 mr-1.5" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="px-4 md:px-6 py-6">
            <TabsContent value="command" className="mt-0">
              {summary && tasks.length > 0 ? (
                <CommandCenter summary={summary} tasks={tasks} />
              ) : (
                <div className="flex items-center justify-center py-20">
                  <div className="w-6 h-6 border-2 border-solar border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="roadmap" className="mt-0">
              {tasks.length > 0 ? <RoadmapPanel tasks={tasks} /> : (
                <div className="flex items-center justify-center py-20">
                  <div className="w-6 h-6 border-2 border-solar border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="timeline" className="mt-0">
              {tasks.length > 0 ? <TimelinePanel tasks={tasks} /> : (
                <div className="flex items-center justify-center py-20">
                  <div className="w-6 h-6 border-2 border-solar border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="agents" className="mt-0">
              <AgentsPanel />
            </TabsContent>
            <TabsContent value="system" className="mt-0">
              {services.length > 0 ? <SystemPanel services={services} /> : (
                <div className="flex items-center justify-center py-20">
                  <div className="w-6 h-6 border-2 border-solar border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="manifesto" className="mt-0">
              <ManifestoPanel />
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-void-lighter bg-void/80 backdrop-blur-sm py-3 px-4 md:px-6">
        <div className="flex items-center justify-between text-[10px] text-steel-dim font-mono">
          <span>NovaHub v0.2.0 — Guarded by Syzygy</span>
          <span>Zero cloud calls. Sovereign.</span>
        </div>
      </footer>
    </div>
  );
}