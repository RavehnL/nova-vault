import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  const services = await db.systemService.findMany({ orderBy: { name: 'asc' } });
  return NextResponse.json(services);
}