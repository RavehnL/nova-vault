import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  const tasks = await db.sprintTask.findMany({ orderBy: { day: 'asc' } });
  return NextResponse.json(tasks);
}

export async function PATCH(request: Request) {
  const body = await request.json();
  const { id, status } = body;
  if (!id || !status) {
    return NextResponse.json({ error: 'id and status required' }, { status: 400 });
  }
  const updated = await db.sprintTask.update({ where: { id }, data: { status } });
  return NextResponse.json(updated);
}