import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  const [tasks, services] = await Promise.all([
    db.sprintTask.findMany({ orderBy: { day: 'asc' } }),
    db.systemService.findMany(),
  ]);

  const completed = tasks.filter(t => t.status === 'completed').length;
  const pending = tasks.filter(t => t.status === 'pending').length;
  const total = tasks.length;
  const running = services.filter(s => s.status === 'running').length;
  const planned = services.filter(s => s.status === 'not_installed').length;

  const lastCompleted = [...tasks].reverse().find(t => t.status === 'completed');
  const currentDay = lastCompleted ? lastCompleted.day + 1 : 1;

  return NextResponse.json({
    total,
    completed,
    pending,
    progress: total > 0 ? Math.round((completed / total) * 100) : 0,
    currentDay,
    servicesRunning: running,
    servicesPlanned: planned,
    totalServices: services.length,
  });
}